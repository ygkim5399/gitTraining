// 1_STL_PREVIEW1
#include <iostream>
#include <string>

int main()
{
	char s1[] = "Hello";
	char s2[] = "Hello";

	if (s1 == s2) {}
	
	s2 = s1;
}