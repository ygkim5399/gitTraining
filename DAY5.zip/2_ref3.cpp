#include <iostream>

void foo(int& a) { a = 200; }

template<typename T> 
void forward_foo(T arg)
{
	foo(arg);
}

int main()
{
	int n = 10;
	
	forward_foo(n);

	std::cout << n << std::endl; 
}
