#include <iostream>
#include <thread>

// atomic

int x = 0;

void foo()
{
	x = x + 1;
}

int main()
{
	std::thread t(&foo);
	t.join();
}