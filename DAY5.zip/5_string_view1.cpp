// 5_string_view
#include <iostream>
#include <string>
#include <string_view> // C++17 ���� �߰�

int main()
{
	std::string s = "to be or not to be";

	std::string		 ss1 = s;
	std::string_view sv1 = s;

	std::string		 ss2 = "to be or not to be";
	std::string_view sv2 = "to be or not to be";
}