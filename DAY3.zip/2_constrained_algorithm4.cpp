#include <iostream>
#include <functional>
#include <vector>
#include <algorithm>
#include "show.h"

int main()
{
	int n1 = std::max(1, 2);
	int n2 = std::ranges::max(1, 2);
}