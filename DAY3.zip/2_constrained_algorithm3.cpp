#include <iostream>
#include <functional>
#include <vector>
#include <algorithm>
#include "show.h"

struct Point
{
	int x, y;
};
int main()
{
	std::vector<Point> v = { {1,2}, {2,3}, {3,4}, {4,5} };

	std::sort(v.begin(), v.end());
}